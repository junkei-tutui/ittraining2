package jp.zein.it.training.was.util.csv;

/**
 * CSVファイルのデータ行を格納するBeanの基底インターフェース。（Was用）
 * <p>
 * 今回はIFのみ
 * <p>
 */
public interface CsvBean {

}
