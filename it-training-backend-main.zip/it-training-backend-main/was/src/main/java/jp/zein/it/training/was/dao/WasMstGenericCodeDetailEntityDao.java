package jp.zein.it.training.was.dao;

import org.seasar.doma.Dao;
import org.seasar.doma.boot.ConfigAutowireable;

@ConfigAutowireable
@Dao
public interface WasMstGenericCodeDetailEntityDao extends jp.zein.it.training.common.dao.CommonMstGenericCodeDetailEntityDao {
}