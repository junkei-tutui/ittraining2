SELECT
        /*%expand*/*
    FROM
        mst_size
    WHERE
    	is_delete = false