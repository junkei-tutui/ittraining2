SELECT
        /*%expand*/*
    FROM
        mst_color
    WHERE
    	is_delete = false