package jp.zein.it.training.common.generate.entity;

import jp.zein.it.training.common.internal.entity.TrainingEntityListener;

/**
 *
 */
public class MstColorEntityListener extends TrainingEntityListener<MstColorEntity> {
}