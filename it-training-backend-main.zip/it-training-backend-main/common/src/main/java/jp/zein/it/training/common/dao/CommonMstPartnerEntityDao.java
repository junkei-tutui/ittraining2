package jp.zein.it.training.common.dao;

import org.seasar.doma.Dao;
import org.seasar.doma.boot.ConfigAutowireable;

@ConfigAutowireable
@Dao
public interface CommonMstPartnerEntityDao extends jp.zein.it.training.common.generate.dao.MstPartnerEntityDao {
}