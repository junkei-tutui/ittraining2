package jp.zein.it.training.common.generate.entity;

import jp.zein.it.training.common.internal.entity.TrainingEntityListener;

/**
 *
 */
public class MstSizeEntityListener extends TrainingEntityListener<MstSizeEntity> {
}