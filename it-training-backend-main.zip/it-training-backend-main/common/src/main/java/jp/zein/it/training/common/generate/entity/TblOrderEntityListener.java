package jp.zein.it.training.common.generate.entity;

import jp.zein.it.training.common.internal.entity.TrainingEntityListener;

/**
 *
 */
public class TblOrderEntityListener extends TrainingEntityListener<TblOrderEntity> {
}